// ─────────────────────────────────────────────────────────────
//  DraftBuddy — App.js
//  Supports: ESPN Fantasy, Yahoo Fantasy, Sleeper
// ─────────────────────────────────────────────────────────────

import React, { useState, useEffect } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, ScrollView,
  StyleSheet, ActivityIndicator, FlatList, Alert,
  SafeAreaView, StatusBar, Platform, Linking, Clipboard,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { getUser, getUserLeagues, getLeagueDrafts, getDraftPicks, formatPicks } from './src/api/sleeper';
import { getESPNLeague, getESPNDraft, parseESPNDraft, findMyESPNTeam } from './src/api/espn';
import { startYahooDeviceFlow, pollYahooToken, getYahooLeagues, getYahooDraft } from './src/api/yahoo';

// ── THEME ─────────────────────────────────────────────────────
const C = {
  bg:'#0a0e1a', surf:'#131929', border:'#1e2d45', muted:'#6b7a99',
  white:'#ffffff', light:'#e8eaf0', green:'#4ade80', teal:'#22d3ee',
  red:'#f87171', orange:'#fb923c', yellow:'#facc15',
  espn:'#e8272a', yahoo:'#7B0099', sleeper:'#4ade80',
};
const POS_COLORS = { QB:'#f87171', RB:'#4ade80', WR:'#818cf8', TE:'#fb923c', K:'#22d3ee', DST:'#6b7a99', '?':'#6b7a99' };

const KEYS = { USER:'@db_user', LEAGUES:'@db_leagues', ESPN_COOKIES:'@db_espn', YAHOO_TOKEN:'@db_yahoo' };

// ─────────────────────────────────────────────────────────────
//  ROOT
// ─────────────────────────────────────────────────────────────
export default function App() {
  const [screen, setScreen]     = useState('splash');
  const [accounts, setAccounts] = useState({ sleeper:null, espn:null, yahoo:null });
  const [leagues, setLeagues]   = useState([]);
  const [draftPicks, setDraftPicks] = useState([]);
  const [selectedLeague, setSelectedLeague] = useState(null);
  const [loading, setLoading]   = useState(false);
  const [error, setError]       = useState('');
  const [yahooFlow, setYahooFlow] = useState(null); // { user_code, device_code, interval }
  const [yahooPolling, setYahooPolling] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const saved = await AsyncStorage.getItem(KEYS.USER);
        if (saved) {
          setAccounts(JSON.parse(saved));
          const savedLeagues = await AsyncStorage.getItem(KEYS.LEAGUES);
          if (savedLeagues) setLeagues(JSON.parse(savedLeagues));
          setScreen('home');
        }
      } catch {}
    })();
  }, []);

  async function saveAccounts(next) {
    setAccounts(next);
    await AsyncStorage.setItem(KEYS.USER, JSON.stringify(next));
  }

  // ── SLEEPER ─────────────────────────────────────────────────
  async function connectSleeper(username) {
    setLoading(true); setError('');
    try {
      const user = await getUser(username.trim());
      const leagueList = await getUserLeagues(user.user_id, 'nfl', '2025');
      const next = { ...accounts, sleeper: { ...user, platform:'sleeper' } };
      await saveAccounts(next);
      const combined = [...leagues, ...(leagueList||[]).map(l => ({ ...l, _platform:'sleeper' }))];
      setLeagues(combined);
      await AsyncStorage.setItem(KEYS.LEAGUES, JSON.stringify(combined));
      setScreen('home');
    } catch(e) { setError(e.message || 'Sleeper username not found.'); }
    finally { setLoading(false); }
  }

  // ── ESPN ─────────────────────────────────────────────────────
  async function connectESPN(leagueId, espn_s2, swid) {
    setLoading(true); setError('');
    try {
      const cookies = espn_s2 ? { espn_s2: espn_s2.trim(), SWID: swid.trim() } : null;
      const data = await getESPNLeague(leagueId.trim(), 2025, 'football', cookies);
      const myTeam = swid ? findMyESPNTeam(data, swid.trim()) : data?.teams?.[0];
      const leagueEntry = {
        _platform:   'espn',
        league_id:   leagueId.trim(),
        name:        data?.settings?.name || `ESPN League ${leagueId}`,
        total_rosters: data?.settings?.size || data?.teams?.length,
        myTeamId:    myTeam?.id,
        cookies,
      };
      const next = { ...accounts, espn: { platform:'espn', leagueId, myTeamId: myTeam?.id, cookies } };
      await saveAccounts(next);
      await AsyncStorage.setItem(KEYS.ESPN_COOKIES, JSON.stringify(cookies));
      const combined = [...leagues.filter(l => l._platform !== 'espn'), leagueEntry];
      setLeagues(combined);
      await AsyncStorage.setItem(KEYS.LEAGUES, JSON.stringify(combined));
      setScreen('home');
    } catch(e) {
      if (e.message === 'PRIVATE_LEAGUE') {
        setError('This is a private ESPN league. Please enter your espn_s2 cookie and SWID below (see instructions).');
      } else {
        setError(e.message || 'Could not connect to ESPN.');
      }
    }
    finally { setLoading(false); }
  }

  // ── YAHOO ────────────────────────────────────────────────────
  async function startYahoo() {
    setLoading(true); setError('');
    try {
      const flow = await startYahooDeviceFlow();
      setYahooFlow(flow);
      setLoading(false);
      // Open yahoo.com/device in browser
      Linking.openURL(flow.verification_uri_complete || 'https://yahoo.com/device');
      // Start polling
      setYahooPolling(true);
      const iv = setInterval(async () => {
        try {
          const result = await pollYahooToken(flow.device_code);
          if (result.access_token) {
            clearInterval(iv);
            setYahooPolling(false);
            const leagueList = await getYahooLeagues(result.access_token, '2025', 'nfl');
            const next = { ...accounts, yahoo: { platform:'yahoo', access_token: result.access_token, refresh_token: result.refresh_token } };
            await saveAccounts(next);
            await AsyncStorage.setItem(KEYS.YAHOO_TOKEN, JSON.stringify(result));
            const tagged = (leagueList||[]).map(l => ({ ...l, _platform:'yahoo', _token: result.access_token }));
            const combined = [...leagues.filter(l => l._platform !== 'yahoo'), ...tagged];
            setLeagues(combined);
            await AsyncStorage.setItem(KEYS.LEAGUES, JSON.stringify(combined));
            setScreen('home');
          }
        } catch {}
      }, (flow.interval || 5) * 1000);
    } catch(e) {
      setError('Could not start Yahoo login. Make sure YAHOO_CLIENT_ID is set in yahoo.js');
      setLoading(false);
    }
  }

  // ── LOAD DRAFT ───────────────────────────────────────────────
  async function loadDraft(league) {
    setSelectedLeague(league);
    setScreen('draft-loading');
    setLoading(true);
    try {
      let picks = [];
      if (league._platform === 'sleeper') {
        const drafts = await getLeagueDrafts(league.league_id);
        if (drafts?.length) {
          const raw = await getDraftPicks(drafts[0].draft_id);
          picks = formatPicks(raw, null);
        }
      } else if (league._platform === 'espn') {
        const data = await getESPNDraft(league.league_id, 2025, 'football', league.cookies);
        picks = parseESPNDraft(data, league.myTeamId);
      } else if (league._platform === 'yahoo') {
        const raw = await getYahooDraft(league.league_key, league._token);
        picks = (raw||[]).map((p,i) => ({ pickNo:p.pick, round:p.round, playerName:`Player ${p.playerKey}`, position:'?', isMine:false }));
      }
      setDraftPicks(picks);
      setScreen('draft');
    } catch(e) {
      Alert.alert('Error', e.message);
      setScreen('home');
    }
    finally { setLoading(false); }
  }

  async function signOut() {
    await AsyncStorage.multiRemove(Object.values(KEYS));
    setAccounts({ sleeper:null, espn:null, yahoo:null });
    setLeagues([]);
    setScreen('splash');
  }

  // ── RENDER ────────────────────────────────────────────────────
  return (
    <SafeAreaView style={s.safe}>
      <StatusBar barStyle="light-content" backgroundColor={C.bg} />
      {screen==='splash'       && <SplashScreen onContinue={()=>setScreen('connect-choose')} />}
      {screen==='connect-choose' && <ChoosePlatform
        accounts={accounts}
        onSleeper={()=>setScreen('connect-sleeper')}
        onESPN={()=>setScreen('connect-espn')}
        onYahoo={()=>setScreen('connect-yahoo')}
        onDone={()=>setScreen('home')}
      />}
      {screen==='connect-sleeper' && <SleeperScreen onSubmit={connectSleeper} loading={loading} error={error} onBack={()=>setScreen('connect-choose')} />}
      {screen==='connect-espn'    && <ESPNScreen onSubmit={connectESPN} loading={loading} error={error} onBack={()=>setScreen('connect-choose')} />}
      {screen==='connect-yahoo'   && <YahooScreen onStart={startYahoo} loading={loading} polling={yahooPolling} flow={yahooFlow} error={error} onBack={()=>setScreen('connect-choose')} />}
      {screen==='home'            && <HomeScreen accounts={accounts} leagues={leagues} onSelectLeague={loadDraft} onAddAccount={()=>setScreen('connect-choose')} onSignOut={signOut} />}
      {screen==='draft-loading'   && <LoadingScreen league={selectedLeague} />}
      {screen==='draft'           && <DraftScreen picks={draftPicks} league={selectedLeague} onBack={()=>setScreen('home')} />}
    </SafeAreaView>
  );
}

// ─────────────────────────────────────────────────────────────
//  SPLASH
// ─────────────────────────────────────────────────────────────
function SplashScreen({ onContinue }) {
  return (
    <ScrollView contentContainerStyle={s.center}>
      <Text style={s.bigLogo}>Draft<Text style={{color:C.green}}>Buddy</Text></Text>
      <Text style={s.splashSub}>Your AI fantasy sports co-pilot.{'\n'}Connect ESPN, Yahoo, or Sleeper to get started.</Text>
      <View style={s.platformRow}>
        <View style={[s.platformBadge,{backgroundColor:'#e8272a22',borderColor:'#e8272a44'}]}><Text style={[s.platformBadgeTxt,{color:C.espn}]}>ESPN</Text></View>
        <View style={[s.platformBadge,{backgroundColor:'#7B009922',borderColor:'#7B009944'}]}><Text style={[s.platformBadgeTxt,{color:C.yahoo}]}>Yahoo</Text></View>
        <View style={[s.platformBadge,{backgroundColor:'#4ade8022',borderColor:'#4ade8044'}]}><Text style={[s.platformBadgeTxt,{color:C.sleeper}]}>Sleeper</Text></View>
      </View>
      <TouchableOpacity style={s.btnPrimary} onPress={onContinue}>
        <Text style={s.btnPrimaryTxt}>Connect your fantasy account →</Text>
      </TouchableOpacity>
      <Text style={s.mutedTxt}>Free · Supports all major platforms</Text>
    </ScrollView>
  );
}

// ─────────────────────────────────────────────────────────────
//  CHOOSE PLATFORM
// ─────────────────────────────────────────────────────────────
function ChoosePlatform({ accounts, onSleeper, onESPN, onYahoo, onDone }) {
  const connected = [accounts.espn, accounts.yahoo, accounts.sleeper].filter(Boolean).length;
  return (
    <ScrollView contentContainerStyle={[s.formScreen,{paddingTop:32}]}>
      <Text style={s.formLogo}>Connect a<Text style={{color:C.green}}> League</Text></Text>
      <Text style={s.formSub}>You can connect multiple platforms at once.</Text>

      {[
        { label:'ESPN Fantasy', sub:'Copy 2 cookies from your browser — takes 2 min', color:C.espn, bg:'#e8272a18', fn:onESPN, connected:!!accounts.espn, icon:'🏆' },
        { label:'Yahoo Fantasy', sub:'Approve access on Yahoo — no password shared', color:C.yahoo, bg:'#7B009918', fn:onYahoo, connected:!!accounts.yahoo, icon:'🟣' },
        { label:'Sleeper', sub:'Just your username — no password needed', color:C.sleeper, bg:'#4ade8018', fn:onSleeper, connected:!!accounts.sleeper, icon:'💤' },
      ].map(p => (
        <TouchableOpacity key={p.label} style={[s.platformCard,{borderColor: p.connected ? p.color+'66' : C.border, backgroundColor: p.connected ? p.bg : C.surf}]} onPress={p.fn}>
          <Text style={{fontSize:28}}>{p.icon}</Text>
          <View style={{flex:1}}>
            <Text style={[s.platformName,{color: p.connected ? p.color : C.white}]}>{p.label}</Text>
            <Text style={s.platformSub}>{p.connected ? '✓ Connected' : p.sub}</Text>
          </View>
          <Text style={[s.lcArrow,{color:p.color}]}>›</Text>
        </TouchableOpacity>
      ))}

      {connected > 0 && (
        <TouchableOpacity style={[s.btnPrimary,{marginTop:12}]} onPress={onDone}>
          <Text style={s.btnPrimaryTxt}>View my leagues →</Text>
        </TouchableOpacity>
      )}
    </ScrollView>
  );
}

// ─────────────────────────────────────────────────────────────
//  SLEEPER SCREEN
// ─────────────────────────────────────────────────────────────
function SleeperScreen({ onSubmit, loading, error, onBack }) {
  const [username, setUsername] = useState('');
  return (
    <ScrollView contentContainerStyle={s.formScreen}>
      <TouchableOpacity onPress={onBack} style={s.backBtn}><Text style={s.backBtnTxt}>‹ Back</Text></TouchableOpacity>
      <Text style={[s.platformName,{fontSize:24,color:C.sleeper,marginBottom:4}]}>💤 Sleeper</Text>
      <Text style={s.formSub}>Enter your username. No password needed.</Text>
      <Text style={s.fieldLabel}>Sleeper username</Text>
      <TextInput style={s.textInput} placeholder="e.g. FantasyKing99" placeholderTextColor={C.muted} value={username} onChangeText={setUsername} autoCapitalize="none" autoCorrect={false} />
      <Text style={s.hintTxt}>In Sleeper: tap your avatar → Profile → your username is at the top</Text>
      {!!error && <View style={s.errBox}><Text style={s.errTxt}>{error}</Text></View>}
      <TouchableOpacity style={[s.btnPrimary,(!username.trim()||loading)&&s.btnDisabled]} onPress={()=>onSubmit(username)} disabled={!username.trim()||loading}>
        {loading ? <ActivityIndicator color={C.bg}/> : <Text style={s.btnPrimaryTxt}>Connect Sleeper →</Text>}
      </TouchableOpacity>
    </ScrollView>
  );
}

// ─────────────────────────────────────────────────────────────
//  ESPN SCREEN
// ─────────────────────────────────────────────────────────────
function ESPNScreen({ onSubmit, loading, error, onBack }) {
  const [leagueId, setLeagueId] = useState('');
  const [espn_s2, setEspnS2]   = useState('');
  const [swid, setSwid]         = useState('');
  const [showCookieHelp, setShowCookieHelp] = useState(false);

  return (
    <ScrollView contentContainerStyle={s.formScreen}>
      <TouchableOpacity onPress={onBack} style={s.backBtn}><Text style={s.backBtnTxt}>‹ Back</Text></TouchableOpacity>
      <Text style={[s.platformName,{fontSize:24,color:C.espn,marginBottom:4}]}>🏆 ESPN Fantasy</Text>
      <Text style={s.formSub}>Public leagues work with just a League ID.{'\n'}Private leagues also need two browser cookies.</Text>

      {/* Step 1 - League ID */}
      <View style={s.stepCard}>
        <Text style={s.stepNum}>Step 1</Text>
        <Text style={s.stepTitle}>Find your League ID</Text>
        <Text style={s.stepDesc}>Open ESPN Fantasy on desktop → go to your league → look at the URL:{'\n\n'}fantasy.espn.com/football/league?leagueId=<Text style={{color:C.espn}}>123456</Text>{'\n\n'}The number at the end is your League ID.</Text>
        <Text style={[s.fieldLabel,{marginTop:12}]}>League ID</Text>
        <TextInput style={s.textInput} placeholder="e.g. 123456" placeholderTextColor={C.muted} value={leagueId} onChangeText={setLeagueId} keyboardType="number-pad" />
      </View>

      {/* Step 2 - Cookies (private leagues) */}
      <TouchableOpacity style={s.stepCard} onPress={()=>setShowCookieHelp(!showCookieHelp)}>
        <View style={{flexDirection:'row',justifyContent:'space-between',alignItems:'center'}}>
          <View>
            <Text style={s.stepNum}>Step 2 (private leagues only)</Text>
            <Text style={s.stepTitle}>Add your ESPN cookies</Text>
          </View>
          <Text style={{color:C.muted,fontSize:18}}>{showCookieHelp?'∧':'∨'}</Text>
        </View>
        {showCookieHelp && (
          <>
            <Text style={[s.stepDesc,{marginTop:10}]}>
              {'1. Open ESPN Fantasy on your computer\n2. Right-click anywhere → Inspect → Application\n3. On the left: Cookies → https://fantasy.espn.com\n4. Find "espn_s2" → copy the whole value\n5. Find "SWID" → copy the whole value (includes { })\n6. Paste both below'}
            </Text>
            <Text style={[s.fieldLabel,{marginTop:12}]}>espn_s2 cookie</Text>
            <TextInput style={[s.textInput,{fontFamily:'monospace',fontSize:11}]} placeholder="AEB...long string..." placeholderTextColor={C.muted} value={espn_s2} onChangeText={setEspnS2} autoCapitalize="none" autoCorrect={false} multiline numberOfLines={3} />
            <Text style={[s.fieldLabel,{marginTop:8}]}>SWID cookie</Text>
            <TextInput style={[s.textInput,{fontFamily:'monospace',fontSize:12}]} placeholder="{XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX}" placeholderTextColor={C.muted} value={swid} onChangeText={setSwid} autoCapitalize="none" autoCorrect={false} />
          </>
        )}
      </TouchableOpacity>

      {!!error && <View style={s.errBox}><Text style={s.errTxt}>{error}</Text></View>}

      <TouchableOpacity style={[s.btnPrimary,{backgroundColor:C.espn},(!leagueId.trim()||loading)&&s.btnDisabled]} onPress={()=>onSubmit(leagueId,espn_s2,swid)} disabled={!leagueId.trim()||loading}>
        {loading ? <ActivityIndicator color={C.white}/> : <Text style={s.btnPrimaryTxt}>Connect ESPN →</Text>}
      </TouchableOpacity>

      <View style={s.securityNote}>
        <Text style={s.securityTxt}>🔒  Your cookies are stored only on your device. DraftBuddy never sends them to any server — all ESPN calls go directly from your phone to ESPN.</Text>
      </View>
    </ScrollView>
  );
}

// ─────────────────────────────────────────────────────────────
//  YAHOO SCREEN
// ─────────────────────────────────────────────────────────────
function YahooScreen({ onStart, loading, polling, flow, error, onBack }) {
  return (
    <ScrollView contentContainerStyle={s.formScreen}>
      <TouchableOpacity onPress={onBack} style={s.backBtn}><Text style={s.backBtnTxt}>‹ Back</Text></TouchableOpacity>
      <Text style={[s.platformName,{fontSize:24,color:C.yahoo,marginBottom:4}]}>🟣 Yahoo Fantasy</Text>
      <Text style={s.formSub}>Approve access safely through Yahoo.{'\n'}No password ever touches DraftBuddy.</Text>

      {!flow && !polling && (
        <>
          <View style={s.stepCard}>
            <Text style={s.stepNum}>How it works</Text>
            <Text style={[s.stepDesc,{marginTop:4}]}>
              {'1. Tap "Connect Yahoo" below\n2. Yahoo opens and shows a short code\n3. Type the code into Yahoo to approve\n4. DraftBuddy automatically loads your leagues\n\nTakes about 60 seconds. No password shared.'}
            </Text>
          </View>
          {!!error && <View style={s.errBox}><Text style={s.errTxt}>{error}</Text></View>}
          <TouchableOpacity style={[s.btnPrimary,{backgroundColor:C.yahoo},loading&&s.btnDisabled]} onPress={onStart} disabled={loading}>
            {loading ? <ActivityIndicator color={C.white}/> : <Text style={s.btnPrimaryTxt}>Connect Yahoo →</Text>}
          </TouchableOpacity>
        </>
      )}

      {(flow || polling) && (
        <View style={[s.stepCard,{alignItems:'center',paddingVertical:32}]}>
          {polling && <ActivityIndicator color={C.yahoo} size="large" style={{marginBottom:20}}/>}
          <Text style={{fontSize:13,color:C.muted,marginBottom:8}}>Go to yahoo.com/device and enter:</Text>
          <View style={{backgroundColor:'#7B009922',borderRadius:12,padding:16,marginBottom:16}}>
            <Text style={{fontSize:36,fontWeight:'900',color:C.yahoo,letterSpacing:8}}>{flow?.user_code || '------'}</Text>
          </View>
          <TouchableOpacity onPress={()=>Linking.openURL('https://yahoo.com/device')}>
            <Text style={{color:C.yahoo,fontSize:14,fontWeight:'600'}}>Open yahoo.com/device →</Text>
          </TouchableOpacity>
          <Text style={[s.mutedTxt,{marginTop:16}]}>Waiting for approval…</Text>
        </View>
      )}
    </ScrollView>
  );
}

// ─────────────────────────────────────────────────────────────
//  LOADING
// ─────────────────────────────────────────────────────────────
function LoadingScreen({ league }) {
  const [step, setStep] = useState(0);
  const steps = ['Joining draft room…','Fetching pick history…','Building draft board…','Almost ready…'];
  useEffect(()=>{
    const iv = setInterval(()=>setStep(s=>Math.min(s+1,steps.length-1)),700);
    return ()=>clearInterval(iv);
  },[]);
  return (
    <View style={[s.center,{gap:16}]}>
      <ActivityIndicator size="large" color={C.green}/>
      <Text style={s.whiteText}>{league?.name||'Loading…'}</Text>
      <Text style={{color:C.green,fontSize:13}}>{steps[step]}</Text>
    </View>
  );
}

// ─────────────────────────────────────────────────────────────
//  HOME — leagues from ALL connected platforms
// ─────────────────────────────────────────────────────────────
function HomeScreen({ accounts, leagues, onSelectLeague, onAddAccount, onSignOut }) {
  const connected = [accounts.espn&&'ESPN', accounts.yahoo&&'Yahoo', accounts.sleeper&&'Sleeper'].filter(Boolean);
  const platformColor = { espn:C.espn, yahoo:C.yahoo, sleeper:C.green };
  const platformIcon  = { espn:'🏆', yahoo:'🟣', sleeper:'💤' };

  return (
    <ScrollView style={s.screen}>
      <View style={s.headerRow}>
        <Text style={s.headerLogo}>Draft<Text style={{color:C.green}}>Buddy</Text></Text>
        <TouchableOpacity style={s.addBtn} onPress={onAddAccount}>
          <Text style={s.addBtnTxt}>+ Connect</Text>
        </TouchableOpacity>
      </View>

      {/* Connected accounts */}
      <View style={s.welcomeCard}>
        <View style={s.greenTopBar}/>
        <Text style={s.welcomeName}>My Accounts</Text>
        <Text style={s.welcomeSub}>{connected.length > 0 ? connected.join(' · ') + ' connected' : 'No accounts connected yet'}</Text>
        <View style={s.statsRow}>
          {['espn','yahoo','sleeper'].map(p => (
            <View key={p} style={[s.statChip,{borderWidth:1,borderColor:accounts[p]?platformColor[p]+'44':C.border}]}>
              <Text style={{fontSize:18}}>{platformIcon[p]}</Text>
              <Text style={[s.statLabel,{color:accounts[p]?platformColor[p]:C.muted,marginTop:4,fontWeight:'600'}]}>
                {accounts[p] ? '✓ On' : 'Off'}
              </Text>
            </View>
          ))}
        </View>
      </View>

      {/* League list */}
      <Text style={s.sectionLabel}>Your Leagues ({leagues.length})</Text>
      {leagues.length === 0
        ? <View style={s.emptyCard}>
            <Text style={s.emptyTxt}>No leagues yet.{'\n'}Tap "+ Connect" to add ESPN, Yahoo, or Sleeper.</Text>
            <TouchableOpacity style={[s.btnPrimary,{marginTop:16}]} onPress={onAddAccount}>
              <Text style={s.btnPrimaryTxt}>Connect a platform →</Text>
            </TouchableOpacity>
          </View>
        : leagues.map((league, i) => {
            const p = league._platform;
            const col = platformColor[p] || C.green;
            return (
              <TouchableOpacity key={i} style={[s.leagueCard,{borderLeftWidth:4,borderLeftColor:col}]} onPress={()=>onSelectLeague(league)}>
                <View style={s.lcLeft}>
                  <Text style={{fontSize:22}}>{platformIcon[p]||'🏈'}</Text>
                  <View style={{flex:1}}>
                    <Text style={s.lcName}>{league.name || league.league_key}</Text>
                    <View style={{flexDirection:'row',alignItems:'center',gap:6,marginTop:3}}>
                      <View style={[s.miniTag,{backgroundColor:col+'22',borderColor:col+'44'}]}>
                        <Text style={[s.miniTagTxt,{color:col}]}>{p?.toUpperCase()}</Text>
                      </View>
                      {league.total_rosters && <Text style={s.lcMeta}>{league.total_rosters} teams</Text>}
                      {league.num_teams     && <Text style={s.lcMeta}>{league.num_teams} teams</Text>}
                    </View>
                  </View>
                </View>
                <Text style={s.lcArrow}>›</Text>
              </TouchableOpacity>
            );
          })
      }

      <TouchableOpacity style={s.signOutBtn} onPress={onSignOut}>
        <Text style={s.signOutTxt}>Sign out of all accounts</Text>
      </TouchableOpacity>
      <View style={{height:32}}/>
    </ScrollView>
  );
}

// ─────────────────────────────────────────────────────────────
//  DRAFT BOARD
// ─────────────────────────────────────────────────────────────
function DraftScreen({ picks, league, onBack }) {
  const p = league?._platform;
  const platformColor = { espn:C.espn, yahoo:C.yahoo, sleeper:C.green };
  const col = platformColor[p] || C.green;
  const myPicks = picks.filter(pk=>pk.isMine);

  return (
    <View style={s.screen}>
      <View style={s.headerRow}>
        <TouchableOpacity onPress={onBack}><Text style={s.backBtnTxt}>‹ Back</Text></TouchableOpacity>
        <Text style={[s.headerLogo,{fontSize:16}]} numberOfLines={1}>{league?.name}</Text>
        <View style={{width:60}}/>
      </View>

      <FlatList
        data={picks}
        keyExtractor={item=>String(item.pickNo)}
        ListHeaderComponent={()=>(
          <>
            <View style={[s.draftSummary,{borderTopColor:col,borderTopWidth:3}]}>
              <View style={{flexDirection:'row',justifyContent:'space-between',alignItems:'flex-start'}}>
                <View>
                  <Text style={s.draftSumTitle}>{league?.name || 'Draft'}</Text>
                  <View style={[s.miniTag,{backgroundColor:col+'22',borderColor:col+'44',marginTop:6}]}>
                    <Text style={[s.miniTagTxt,{color:col}]}>{p?.toUpperCase()} · {picks.length} picks</Text>
                  </View>
                </View>
                <View style={{alignItems:'center'}}>
                  <Text style={{fontSize:28,fontWeight:'900',color:C.green}}>{myPicks.length>0?'A':'?'}</Text>
                  <Text style={s.gradeLabel}>Grade</Text>
                </View>
              </View>
              {myPicks.length > 0 && (
                <>
                  <Text style={[s.miniLabel,{marginTop:14}]}>Your picks ({myPicks.length})</Text>
                  <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                    {myPicks.slice(0,10).map(pk=>(
                      <View key={pk.pickNo} style={s.myPickChip}>
                        <Text style={[s.mpPos,{color:POS_COLORS[pk.position]||C.muted}]}>{pk.position}</Text>
                        <Text style={s.mpName} numberOfLines={1}>{pk.playerName?.split(' ').pop()}</Text>
                        <Text style={s.mpRound}>Rd {pk.round}</Text>
                      </View>
                    ))}
                  </ScrollView>
                </>
              )}
            </View>
            <Text style={s.sectionLabel}>Full draft board — {picks.length} picks</Text>
          </>
        )}
        renderItem={({item})=>(
          <View style={[s.pickRow,item.isMine&&s.pickRowMine]}>
            <Text style={[s.pickNum,{color:item.isMine?C.green:C.muted}]}>#{item.pickNo}</Text>
            <View style={[s.posBadge,{backgroundColor:(POS_COLORS[item.position]||C.muted)+'22'}]}>
              <Text style={[s.posTxt,{color:POS_COLORS[item.position]||C.muted}]}>{item.position}</Text>
            </View>
            <View style={{flex:1}}>
              <Text style={[s.playerName,item.isMine&&{color:C.white}]}>{item.playerName}</Text>
              <Text style={s.playerTeam}>{item.teamName||item.team||''}{item.round?` · Round ${item.round}`:''}</Text>
            </View>
            {item.isMine&&<View style={s.myTag}><Text style={s.myTagTxt}>You</Text></View>}
          </View>
        )}
        ListFooterComponent={()=><View style={{height:32}}/>}
        style={s.screen}
      />
    </View>
  );
}

// ─────────────────────────────────────────────────────────────
//  STYLES
// ─────────────────────────────────────────────────────────────
const s = StyleSheet.create({
  safe:{flex:1,backgroundColor:C.bg},
  screen:{flex:1,backgroundColor:C.bg},
  center:{flex:1,alignItems:'center',justifyContent:'center',padding:28},
  formScreen:{padding:24,paddingTop:16},
  bigLogo:{fontSize:52,fontWeight:'900',color:C.white,marginBottom:12,textAlign:'center'},
  splashSub:{fontSize:15,color:C.muted,textAlign:'center',lineHeight:24,marginBottom:28},
  platformRow:{flexDirection:'row',gap:10,marginBottom:32},
  platformBadge:{borderRadius:20,paddingVertical:7,paddingHorizontal:14,borderWidth:1},
  platformBadgeTxt:{fontSize:14,fontWeight:'700'},
  mutedTxt:{fontSize:12,color:C.muted,textAlign:'center'},
  btnPrimary:{backgroundColor:C.green,borderRadius:14,padding:16,alignItems:'center',marginBottom:12,width:'100%'},
  btnPrimaryTxt:{color:C.bg,fontSize:16,fontWeight:'700'},
  btnDisabled:{opacity:0.4},
  backBtn:{marginBottom:20},
  backBtnTxt:{color:C.muted,fontSize:14},
  formLogo:{fontSize:28,fontWeight:'900',color:C.white,marginBottom:4},
  formSub:{fontSize:14,color:C.muted,marginBottom:20,lineHeight:20},
  fieldLabel:{fontSize:11,color:C.muted,textTransform:'uppercase',letterSpacing:.8,fontWeight:'600',marginBottom:6},
  textInput:{backgroundColor:C.surf,borderWidth:1,borderColor:C.border,borderRadius:12,padding:14,color:C.white,fontSize:15,marginBottom:6},
  hintTxt:{fontSize:12,color:C.muted,marginBottom:16},
  errBox:{backgroundColor:'rgba(248,113,113,0.08)',borderWidth:1,borderColor:'rgba(248,113,113,0.2)',borderRadius:10,padding:12,marginBottom:16},
  errTxt:{color:C.red,fontSize:13},
  stepCard:{backgroundColor:C.surf,borderRadius:14,padding:16,borderWidth:1,borderColor:C.border,marginBottom:12},
  stepNum:{fontSize:11,color:C.muted,textTransform:'uppercase',letterSpacing:.8,fontWeight:'600',marginBottom:4},
  stepTitle:{fontSize:15,fontWeight:'700',color:C.white,marginBottom:2},
  stepDesc:{fontSize:13,color:'#8b9cbf',lineHeight:20},
  securityNote:{backgroundColor:'rgba(74,222,128,0.06)',borderWidth:1,borderColor:'rgba(74,222,128,0.15)',borderRadius:12,padding:14,marginTop:4},
  securityTxt:{fontSize:12,color:'#8b9cbf',lineHeight:18},
  platformCard:{flexDirection:'row',alignItems:'center',gap:14,backgroundColor:C.surf,borderRadius:14,padding:16,borderWidth:1,borderColor:C.border,marginBottom:10},
  platformName:{fontSize:16,fontWeight:'700',color:C.white,marginBottom:2},
  platformSub:{fontSize:12,color:C.muted},
  headerRow:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',padding:20,paddingBottom:0},
  headerLogo:{fontSize:22,fontWeight:'900',color:C.white,flex:1},
  addBtn:{backgroundColor:C.surf,borderWidth:1,borderColor:C.border,borderRadius:20,paddingVertical:6,paddingHorizontal:14},
  addBtnTxt:{color:C.green,fontSize:13,fontWeight:'600'},
  welcomeCard:{margin:16,backgroundColor:C.surf,borderRadius:16,padding:18,borderWidth:1,borderColor:C.border,overflow:'hidden'},
  greenTopBar:{position:'absolute',top:0,left:0,right:0,height:3,backgroundColor:C.green},
  welcomeName:{fontSize:18,fontWeight:'800',color:C.white,marginBottom:2,marginTop:4},
  welcomeSub:{fontSize:13,color:C.muted},
  statsRow:{flexDirection:'row',gap:8,marginTop:14},
  statChip:{flex:1,backgroundColor:'#0f1421',borderRadius:10,padding:10,alignItems:'center'},
  statNum:{fontSize:18,fontWeight:'800',color:C.green},
  statLabel:{fontSize:10,color:C.muted,marginTop:2},
  sectionLabel:{paddingHorizontal:20,paddingTop:16,paddingBottom:8,fontSize:11,color:C.muted,textTransform:'uppercase',letterSpacing:1,fontWeight:'600'},
  leagueCard:{marginHorizontal:20,marginBottom:10,backgroundColor:C.surf,borderRadius:14,padding:16,borderWidth:1,borderColor:C.border,flexDirection:'row',alignItems:'center',justifyContent:'space-between'},
  lcLeft:{flexDirection:'row',alignItems:'center',gap:12,flex:1},
  lcName:{fontSize:15,fontWeight:'600',color:C.white,marginBottom:2},
  lcMeta:{fontSize:12,color:C.muted},
  lcArrow:{fontSize:20,color:C.muted},
  miniTag:{borderWidth:1,borderRadius:8,paddingVertical:2,paddingHorizontal:7,alignSelf:'flex-start'},
  miniTagTxt:{fontSize:10,fontWeight:'700'},
  emptyCard:{marginHorizontal:20,backgroundColor:C.surf,borderRadius:14,padding:20,borderWidth:1,borderColor:C.border,alignItems:'center'},
  emptyTxt:{color:C.muted,fontSize:14,textAlign:'center',lineHeight:22},
  signOutBtn:{marginHorizontal:20,marginTop:24,padding:14,borderRadius:14,borderWidth:1,borderColor:C.border,alignItems:'center'},
  signOutTxt:{color:C.red,fontSize:14,fontWeight:'500'},
  draftSummary:{margin:16,backgroundColor:C.surf,borderRadius:16,padding:18,borderWidth:1,borderColor:C.border,overflow:'hidden'},
  draftSumTitle:{fontSize:18,fontWeight:'800',color:C.white},
  gradeLabel:{fontSize:10,color:C.muted},
  miniLabel:{fontSize:11,color:C.muted,textTransform:'uppercase',letterSpacing:.8,marginBottom:10},
  myPickChip:{backgroundColor:'#0f1421',borderRadius:10,padding:10,marginRight:8,alignItems:'center',minWidth:64},
  mpPos:{fontSize:10,fontWeight:'700',marginBottom:2},
  mpName:{fontSize:12,color:C.white,fontWeight:'500',maxWidth:64},
  mpRound:{fontSize:10,color:C.muted,marginTop:2},
  pickRow:{marginHorizontal:20,marginBottom:6,backgroundColor:C.surf,borderRadius:12,padding:12,flexDirection:'row',alignItems:'center',gap:10,borderWidth:1,borderColor:'transparent'},
  pickRowMine:{borderColor:'rgba(74,222,128,0.25)',backgroundColor:'rgba(74,222,128,0.04)'},
  pickNum:{fontSize:12,fontWeight:'700',width:28,textAlign:'center'},
  posBadge:{width:32,height:32,borderRadius:8,alignItems:'center',justifyContent:'center'},
  posTxt:{fontSize:10,fontWeight:'700'},
  playerName:{fontSize:13,fontWeight:'500',color:'#8b9cbf'},
  playerTeam:{fontSize:11,color:C.muted,marginTop:1},
  myTag:{backgroundColor:'rgba(74,222,128,0.12)',borderRadius:6,paddingHorizontal:8,paddingVertical:3},
  myTagTxt:{fontSize:10,color:C.green,fontWeight:'700'},
  whiteText:{color:C.white,fontSize:16,fontWeight:'600',textAlign:'center'},
});
