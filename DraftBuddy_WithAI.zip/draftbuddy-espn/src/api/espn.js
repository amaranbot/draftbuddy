// ─────────────────────────────────────────────────────────────
//  ESPN Fantasy API
//
//  ESPN has TWO types of leagues:
//  1. PUBLIC leagues  → work with no login at all
//  2. PRIVATE leagues → need cookies from browser (see below)
//
//  The trick everyone uses: ESPN stores auth in two cookies
//  called espn_s2 and SWID. You copy them from your browser
//  and paste them into DraftBuddy once. That's it — no password
//  ever touches our app.
// ─────────────────────────────────────────────────────────────

const ESPN_BASE = 'https://fantasy.espn.com/apis/v3/games';

// Sport slugs ESPN uses internally
const ESPN_SPORT = {
  football:   'ffl',   // NFL
  basketball:  'fba',   // NBA
  baseball:   'flb',   // MLB
  hockey:     'fhl',   // NHL
};

// ── Get league info + teams ───────────────────────────────────
// leagueId: the number in your ESPN league URL
// season:   year e.g. 2025
// cookies:  { espn_s2, SWID } — only needed for private leagues
export async function getESPNLeague(leagueId, season = 2025, sport = 'football', cookies = null) {
  const slug = ESPN_SPORT[sport] || 'ffl';
  const url  = `${ESPN_BASE}/${slug}/seasons/${season}/segments/0/leagues/${leagueId}?view=mTeam&view=mRoster&view=mSettings`;

  const headers = { 'Content-Type': 'application/json' };
  if (cookies?.espn_s2) headers['Cookie'] = `espn_s2=${cookies.espn_s2}; SWID=${cookies.SWID}`;

  const res = await fetch(url, { headers });
  if (res.status === 401) throw new Error('PRIVATE_LEAGUE'); // needs cookies
  if (!res.ok) throw new Error(`ESPN error: ${res.status}`);
  return res.json();
}

// ── Get draft recap ───────────────────────────────────────────
export async function getESPNDraft(leagueId, season = 2025, sport = 'football', cookies = null) {
  const slug = ESPN_SPORT[sport] || 'ffl';
  const url  = `${ESPN_BASE}/${slug}/seasons/${season}/segments/0/leagues/${leagueId}?view=mDraftDetail&view=mSettings&view=mTeam&view=mRoster`;

  const headers = { 'Content-Type': 'application/json' };
  if (cookies?.espn_s2) headers['Cookie'] = `espn_s2=${cookies.espn_s2}; SWID=${cookies.SWID}`;

  const res = await fetch(url, { headers });
  if (res.status === 401) throw new Error('PRIVATE_LEAGUE');
  if (!res.ok) throw new Error(`ESPN draft error: ${res.status}`);
  return res.json();
}

// ── Get scoreboard / matchups ─────────────────────────────────
export async function getESPNScoreboard(leagueId, season = 2025, week = 1, sport = 'football', cookies = null) {
  const slug = ESPN_SPORT[sport] || 'ffl';
  const url  = `${ESPN_BASE}/${slug}/seasons/${season}/segments/0/leagues/${leagueId}?view=mScoreboard&scoringPeriodId=${week}`;

  const headers = { 'Content-Type': 'application/json' };
  if (cookies?.espn_s2) headers['Cookie'] = `espn_s2=${cookies.espn_s2}; SWID=${cookies.SWID}`;

  const res = await fetch(url, { headers });
  if (!res.ok) throw new Error(`ESPN scoreboard error: ${res.status}`);
  return res.json();
}

// ── Parse draft picks from ESPN response ─────────────────────
export function parseESPNDraft(data, myTeamId) {
  const picks = data?.draftDetail?.picks || [];
  const teams = {};
  (data?.teams || []).forEach(t => {
    teams[t.id] = t.name || `Team ${t.id}`;
  });

  return picks.map(p => ({
    pickNo:     p.overallPickNumber,
    round:      p.roundId,
    teamId:     p.teamId,
    isMine:     p.teamId === myTeamId,
    playerName: `${p.playerPoolEntry?.playerPoolEntry?.player?.firstName || ''} ${p.playerPoolEntry?.playerPoolEntry?.player?.lastName || p.playerId}`.trim(),
    position:   positionMap[p.playerPoolEntry?.playerPoolEntry?.player?.defaultPositionId] || '?',
    teamName:   teams[p.teamId] || `Team ${p.teamId}`,
  }));
}

const positionMap = { 1:'QB', 2:'RB', 3:'WR', 4:'TE', 5:'K', 16:'DST' };

// ── Find my team in a league ──────────────────────────────────
export function findMyESPNTeam(data, swid) {
  if (!swid) return null;
  return data?.teams?.find(t =>
    t?.owners?.some(o => o === swid || o === `{${swid}}`)
  );
}
