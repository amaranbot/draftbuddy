// ─────────────────────────────────────────────────────────────
//  Yahoo Fantasy API
//
//  Yahoo requires OAuth 2.0 for ALL requests (even public leagues).
//  
//  The simplest no-backend approach:
//  Yahoo has a "YQL" (Yahoo Query Language) endpoint that works
//  with a public app key for READ-ONLY fantasy data.
//
//  Setup (one-time, free):
//  1. Go to developer.yahoo.com/apps/create
//  2. Create a free app — select "Fantasy Sports" API
//  3. Copy your Client ID (public, safe to ship in app)
//  4. Use the device flow to let users log in on their phone
//
//  The code below uses Yahoo's OAuth Device Flow —
//  user sees a code, goes to yahoo.com/device, types it in.
//  No redirect server needed. Works 100% in a mobile app.
// ─────────────────────────────────────────────────────────────

const YAHOO_CLIENT_ID = 'YOUR_YAHOO_CLIENT_ID'; // replace with yours from developer.yahoo.com
const YAHOO_BASE      = 'https://fantasysports.yahooapis.com/fantasy/v2';
const YAHOO_AUTH      = 'https://api.login.yahoo.com/oauth2';

// ── Step 1: Start device login flow ──────────────────────────
// Call this when user taps "Connect Yahoo"
// Returns: { device_code, user_code, verification_uri, expires_in, interval }
// Show user_code to the user and tell them to go to verification_uri
export async function startYahooDeviceFlow() {
  const res = await fetch(`${YAHOO_AUTH}/device/request_auth`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: `client_id=${YAHOO_CLIENT_ID}&response_type=device_token`,
  });
  if (!res.ok) throw new Error('Could not start Yahoo login');
  return res.json();
}

// ── Step 2: Poll for access token ────────────────────────────
// Call this every `interval` seconds until success or expiry
// Returns: { access_token, refresh_token, expires_in } on success
//          { error: 'authorization_pending' } while waiting
export async function pollYahooToken(deviceCode) {
  const res = await fetch(`${YAHOO_AUTH}/get_token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: `client_id=${YAHOO_CLIENT_ID}&grant_type=device_token&device_code=${deviceCode}`,
  });
  return res.json();
}

// ── Step 3: Refresh token when expired ───────────────────────
export async function refreshYahooToken(refreshToken) {
  const res = await fetch(`${YAHOO_AUTH}/get_token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: `client_id=${YAHOO_CLIENT_ID}&grant_type=refresh_token&refresh_token=${refreshToken}`,
  });
  if (!res.ok) throw new Error('Could not refresh Yahoo token');
  return res.json();
}

// ── Get user's leagues ────────────────────────────────────────
export async function getYahooLeagues(accessToken, season = '2025', sport = 'nfl') {
  const gameKey = getYahooGameKey(sport, season);
  const res = await fetch(
    `${YAHOO_BASE}/users;use_login=1/games;game_keys=${gameKey}/leagues?format=json`,
    { headers: { Authorization: `Bearer ${accessToken}` } }
  );
  if (!res.ok) throw new Error('Could not load Yahoo leagues');
  const data = await res.json();
  return parseYahooLeagues(data);
}

// ── Get draft results ─────────────────────────────────────────
export async function getYahooDraft(leagueKey, accessToken) {
  const res = await fetch(
    `${YAHOO_BASE}/league/${leagueKey}/draftresults?format=json`,
    { headers: { Authorization: `Bearer ${accessToken}` } }
  );
  if (!res.ok) throw new Error('Could not load Yahoo draft');
  const data = await res.json();
  return parseYahooDraft(data);
}

// ── Get rosters ───────────────────────────────────────────────
export async function getYahooRoster(teamKey, accessToken) {
  const res = await fetch(
    `${YAHOO_BASE}/team/${teamKey}/roster/players?format=json`,
    { headers: { Authorization: `Bearer ${accessToken}` } }
  );
  if (!res.ok) throw new Error('Could not load Yahoo roster');
  return res.json();
}

// ── Helpers ───────────────────────────────────────────────────
function getYahooGameKey(sport, season) {
  const keys = {
    nfl: { '2025': '449', '2024': '423' },
    nba: { '2025': '428', '2024': '418' },
    mlb: { '2025': '422', '2024': '411' },
    nhl: { '2025': '427', '2024': '419' },
  };
  return keys[sport]?.[season] || keys.nfl['2025'];
}

function parseYahooLeagues(data) {
  try {
    const games = data?.fantasy_content?.users?.[0]?.user?.[1]?.games;
    if (!games) return [];
    const game  = games[0]?.game?.[1];
    const leagues = game?.leagues || {};
    return Object.values(leagues)
      .filter(l => l?.league)
      .map(l => ({
        league_key:  l.league[0].league_key,
        name:        l.league[0].name,
        num_teams:   l.league[0].num_teams,
        draft_status: l.league[0].draft_status,
        scoring_type: l.league[0].scoring_type,
      }));
  } catch { return []; }
}

function parseYahooDraft(data) {
  try {
    const picks = data?.fantasy_content?.league?.[1]?.draft_results?.[0]?.draft_results || {};
    return Object.values(picks)
      .filter(p => p?.draft_result)
      .map(p => ({
        pick:   p.draft_result.pick,
        round:  p.draft_result.round,
        teamKey: p.draft_result.team_key,
        playerKey: p.draft_result.player_key,
      }));
  } catch { return []; }
}
