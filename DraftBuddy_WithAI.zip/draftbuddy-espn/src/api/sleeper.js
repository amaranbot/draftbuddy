// ─────────────────────────────────────────────
//  DraftBuddy — Sleeper API
//  100% free, no key needed, no backend needed
//  All calls go straight to api.sleeper.com
// ─────────────────────────────────────────────

const BASE = 'https://api.sleeper.app/v1';

// ── 1. Get user by username ──────────────────
// Returns: { user_id, username, display_name, avatar }
export async function getUser(username) {
  const res = await fetch(`${BASE}/user/${username}`);
  if (!res.ok) throw new Error('User not found');
  return res.json();
}

// ── 2. Get all leagues for a user ───────────
// sport: 'nfl' | 'nba' | 'nhl' | 'mlb'
// season: '2025' (current year)
// Returns: array of league objects
export async function getUserLeagues(userId, sport = 'nfl', season = '2025') {
  const res = await fetch(`${BASE}/user/${userId}/leagues/${sport}/${season}`);
  if (!res.ok) throw new Error('Could not load leagues');
  return res.json();
}

// ── 3. Get rosters in a league ──────────────
// Returns: array of roster objects (each has owner_id, players[], starters[])
export async function getLeagueRosters(leagueId) {
  const res = await fetch(`${BASE}/league/${leagueId}/rosters`);
  if (!res.ok) throw new Error('Could not load rosters');
  return res.json();
}

// ── 4. Get all users in a league ────────────
// Returns: array of user objects with display_name
export async function getLeagueUsers(leagueId) {
  const res = await fetch(`${BASE}/league/${leagueId}/users`);
  if (!res.ok) throw new Error('Could not load users');
  return res.json();
}

// ── 5. Get draft for a league ───────────────
// Returns: array of draft objects for the league
export async function getLeagueDrafts(leagueId) {
  const res = await fetch(`${BASE}/league/${leagueId}/drafts`);
  if (!res.ok) throw new Error('Could not load drafts');
  return res.json();
}

// ── 6. Get all picks in a draft ─────────────
// Returns: array of pick objects
// Each pick: { pick_no, round, roster_id, player_id, metadata: { first_name, last_name, position, team } }
export async function getDraftPicks(draftId) {
  const res = await fetch(`${BASE}/draft/${draftId}/picks`);
  if (!res.ok) throw new Error('Could not load picks');
  return res.json();
}

// ── 7. Get draft details ─────────────────────
// Returns: { status, type, season, settings: { teams, rounds }, draft_order, slot_to_roster_id }
export async function getDraft(draftId) {
  const res = await fetch(`${BASE}/draft/${draftId}`);
  if (!res.ok) throw new Error('Could not load draft');
  return res.json();
}

// ── 8. Get player info (all NFL players) ────
// Returns: big object keyed by player_id
// Cache this — it's a large payload (~3MB)
let playerCache = null;
export async function getAllPlayers(sport = 'nfl') {
  if (playerCache) return playerCache;
  const res = await fetch(`${BASE}/players/${sport}`);
  if (!res.ok) throw new Error('Could not load players');
  playerCache = await res.json();
  return playerCache;
}

// ── 9. Get traded picks ──────────────────────
export async function getTradedPicks(leagueId) {
  const res = await fetch(`${BASE}/league/${leagueId}/traded_picks`);
  if (!res.ok) return [];
  return res.json();
}

// ── HELPERS ──────────────────────────────────

// Find which roster slot belongs to our user
export function findMyRoster(rosters, userId) {
  return rosters.find(r => r.owner_id === userId);
}

// Build a human-readable pick list from raw picks + player data
export function formatPicks(picks, myRosterId) {
  return picks.map(pick => ({
    pickNo:    pick.pick_no,
    round:     pick.round,
    isMine:    pick.roster_id === myRosterId,
    playerName: pick.metadata
      ? `${pick.metadata.first_name} ${pick.metadata.last_name}`
      : 'Unknown',
    position:  pick.metadata?.position || '?',
    team:      pick.metadata?.team || '?',
    avatar:    pick.metadata?.avatar || null,
  }));
}

// Grade a draft A-F based on ADP value (simplified)
export function gradeDraft(picks, myRosterId) {
  const mine = picks.filter(p => p.roster_id === myRosterId);
  if (!mine.length) return { grade: '?', color: '#6b7a99' };
  // Simple heuristic: did we get value vs pick position?
  const grades = [
    { grade: 'A+', color: '#facc15' },
    { grade: 'A',  color: '#4ade80' },
    { grade: 'B+', color: '#38bdf8' },
    { grade: 'B',  color: '#818cf8' },
    { grade: 'C',  color: '#fb923c' },
  ];
  return grades[Math.floor(Math.random() * grades.length)]; // replace with real ADP logic
}
