// ─────────────────────────────────────────────────────────────
//  DraftBuddy — AI Draft Assistant
//  Real Anthropic API calls during live ESPN/Yahoo/Sleeper drafts
//
//  Setup: add EXPO_PUBLIC_ANTHROPIC_API_KEY to your .env file
//  Get a key at: console.anthropic.com
// ─────────────────────────────────────────────────────────────

const ANTHROPIC_API = 'https://api.anthropic.com/v1/messages';
const MODEL = 'claude-sonnet-4-20250514';

// ── Build the system prompt from live draft context ───────────
// This is what makes recommendations SPECIFIC to your real draft
function buildSystemPrompt(ctx) {
  const needsStr = ctx.needs.join(', ') || 'flex depth';
  const rosterStr = ctx.myRoster.map(p => `${p.name} (${p.position})`).join(', ') || 'none yet';
  const takenStr = ctx.recentlyTaken.slice(-10).join(', ');
  const availStr = ctx.available.slice(0, 30).map(p => `${p.name} (${p.position}, ${p.team})`).join(', ');

  return `You are DraftBuddy, an expert AI fantasy sports co-pilot embedded inside a live ${ctx.platform.toUpperCase()} Fantasy draft.

LIVE DRAFT CONTEXT:
- Platform: ${ctx.platform.toUpperCase()} Fantasy
- Sport: ${ctx.sport || 'NFL'}
- League: ${ctx.leagueName} (${ctx.teamCount}-team, ${ctx.scoringType})
- Round: ${ctx.round} of ${ctx.totalRounds}
- Current pick: #${ctx.currentPick} of ${ctx.totalPicks}
- User's next pick: #${ctx.myNextPick}
- Picks until user's turn: ${ctx.myNextPick - ctx.currentPick}

MY ROSTER SO FAR:
${rosterStr}

ROSTER NEEDS (positions still open):
${needsStr}

RECENTLY DRAFTED BY OTHERS:
${takenStr}

TOP AVAILABLE PLAYERS:
${availStr}

INSTRUCTIONS:
- Give ONE clear pick recommendation with a confidence percentage
- Explain why in 2-3 sentences SPECIFIC to this roster and situation
- Mention the platform-specific ADP context (${ctx.platform.toUpperCase()} ADP)
- Call out if this is a value pick (getting them early) or a need pick
- Be decisive and confident — the user has 60 seconds to pick
- Format: Start with the player name bolded, then confidence %, then reasoning
- Keep response under 80 words total`;
}

// ── Main AI recommendation call ───────────────────────────────
export async function getAIRecommendation(draftContext) {
  const apiKey = process.env.EXPO_PUBLIC_ANTHROPIC_API_KEY;
  if (!apiKey) {
    throw new Error('ANTHROPIC_KEY_MISSING');
  }

  const systemPrompt = buildSystemPrompt(draftContext);

  const response = await fetch(ANTHROPIC_API, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': apiKey,
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify({
      model: MODEL,
      max_tokens: 200,
      system: systemPrompt,
      messages: [{
        role: 'user',
        content: `It's pick #${draftContext.myNextPick} — my turn in ${draftContext.myNextPick - draftContext.currentPick} picks. Who should I draft?`
      }]
    })
  });

  if (!response.ok) {
    const err = await response.json();
    throw new Error(err?.error?.message || `API error ${response.status}`);
  }

  const data = await response.json();
  return data?.content?.[0]?.text || '';
}

// ── Ask any question about the draft ─────────────────────────
export async function askDraftQuestion(question, draftContext) {
  const apiKey = process.env.EXPO_PUBLIC_ANTHROPIC_API_KEY;
  if (!apiKey) throw new Error('ANTHROPIC_KEY_MISSING');

  const systemPrompt = buildSystemPrompt(draftContext);

  const response = await fetch(ANTHROPIC_API, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': apiKey,
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify({
      model: MODEL,
      max_tokens: 150,
      system: systemPrompt,
      messages: [{ role: 'user', content: question }]
    })
  });

  if (!response.ok) throw new Error('AI request failed');
  const data = await response.json();
  return data?.content?.[0]?.text || '';
}

// ── Trade analysis ────────────────────────────────────────────
export async function analyzeTradeOffer(give, receive, draftContext) {
  const apiKey = process.env.EXPO_PUBLIC_ANTHROPIC_API_KEY;
  if (!apiKey) throw new Error('ANTHROPIC_KEY_MISSING');

  const response = await fetch(ANTHROPIC_API, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': apiKey,
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify({
      model: MODEL,
      max_tokens: 150,
      system: `You are DraftBuddy, an expert fantasy sports trade analyzer for ${draftContext?.platform?.toUpperCase() || 'ESPN'} Fantasy.`,
      messages: [{
        role: 'user',
        content: `Analyze this trade in a ${draftContext?.scoringType || 'PPR'} league:
I GIVE: ${give.join(', ')}
I RECEIVE: ${receive.join(', ')}
My current roster needs: ${draftContext?.needs?.join(', ') || 'WR, TE'}

Give: Accept/Decline/Counter, value difference, and one sentence of reasoning. Be direct.`
      }]
    })
  });

  if (!response.ok) throw new Error('Trade analysis failed');
  const data = await response.json();
  return data?.content?.[0]?.text || '';
}

// ── Start/sit advice ──────────────────────────────────────────
export async function getStartSitAdvice(players, week, platform) {
  const apiKey = process.env.EXPO_PUBLIC_ANTHROPIC_API_KEY;
  if (!apiKey) throw new Error('ANTHROPIC_KEY_MISSING');

  const playerList = players.map(p => `${p.name} (${p.position}, ${p.team}, opponent: ${p.opponent || 'TBD'})`).join('\n');

  const response = await fetch(ANTHROPIC_API, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': apiKey,
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify({
      model: MODEL,
      max_tokens: 200,
      system: `You are DraftBuddy, expert ${platform?.toUpperCase() || 'ESPN'} Fantasy football start/sit advisor for Week ${week}.`,
      messages: [{
        role: 'user',
        content: `Who should I start this week? Rank these players and explain briefly:\n${playerList}`
      }]
    })
  });

  if (!response.ok) throw new Error('Start/sit request failed');
  const data = await response.json();
  return data?.content?.[0]?.text || '';
}

// ── Build live draft context from ESPN/Yahoo/Sleeper data ─────
// Call this to assemble the context object before asking AI
export function buildDraftContext({
  platform,        // 'espn' | 'yahoo' | 'sleeper'
  leagueName,
  teamCount,
  scoringType,     // 'PPR' | 'Standard' | 'Half-PPR'
  sport = 'NFL',
  round,
  totalRounds,
  currentPick,
  totalPicks,
  myNextPick,
  myRoster,        // array of { name, position, team }
  allPicks,        // all picks made so far
  availablePlayers,// array of { name, position, team, adp }
}) {
  // Figure out what positions I still need
  const have = myRoster.map(p => p.position);
  const needs = [];
  if (!have.includes('QB'))  needs.push('QB');
  if (have.filter(p=>p==='RB').length < 2) needs.push('RB');
  if (have.filter(p=>p==='WR').length < 2) needs.push('WR');
  if (!have.includes('TE'))  needs.push('TE');
  if (!have.includes('K'))   needs.push('K');
  if (!have.includes('DST')) needs.push('DST');

  // Recent picks by others (last 10)
  const recentlyTaken = allPicks
    .slice(-10)
    .map(p => `${p.playerName} (${p.position})`);

  // Top available sorted by ADP
  const available = (availablePlayers || [])
    .sort((a, b) => (a.adp || 999) - (b.adp || 999))
    .slice(0, 40);

  return {
    platform, leagueName, teamCount, scoringType, sport,
    round, totalRounds, currentPick, totalPicks, myNextPick,
    myRoster, needs, recentlyTaken, available,
  };
}
