// ─────────────────────────────────────────────────────────────
//  DraftBuddy — LiveDraftScreen.js
//  Drop this into src/screens/LiveDraftScreen.js
//
//  This is the full live draft screen with:
//  - Real pick countdown timer
//  - AI recommendation that updates every pick
//  - Ask AI anything input
//  - Live pick feed from ESPN/Yahoo/Sleeper
// ─────────────────────────────────────────────────────────────

import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, ScrollView,
  StyleSheet, ActivityIndicator, FlatList, Alert, Vibration,
} from 'react-native';
import { getAIRecommendation, askDraftQuestion, buildDraftContext } from '../api/ai';

const C = {
  bg:'#0a0e1a', surf:'#131929', border:'#1e2d45', muted:'#6b7a99',
  white:'#ffffff', light:'#e8eaf0', green:'#4ade80', teal:'#22d3ee',
  red:'#f87171', orange:'#fb923c',
};

const POS_COLORS = {
  QB:'#f87171', RB:'#4ade80', WR:'#818cf8',
  TE:'#fb923c', K:'#22d3ee', DST:'#6b7a99', '?':'#6b7a99',
};

// ── MAIN SCREEN ───────────────────────────────────────────────
export default function LiveDraftScreen({
  league,          // league object from ESPN/Yahoo/Sleeper
  platform,        // 'espn' | 'yahoo' | 'sleeper'
  myRoster,        // current roster array
  allPicks,        // all picks made so far (live updated)
  availablePlayers,// available player pool
  myNextPick,      // pick number for my next pick
  currentPick,     // current overall pick number
  round,
  onBack,
  onPickMade,      // callback when user confirms a pick
}) {
  const [aiRec, setAiRec]           = useState(null);
  const [aiLoading, setAiLoading]   = useState(false);
  const [aiError, setAiError]       = useState('');
  const [question, setQuestion]     = useState('');
  const [qAnswer, setQAnswer]       = useState('');
  const [qLoading, setQLoading]     = useState(false);
  const [timer, setTimer]           = useState(60);
  const [isMyTurn, setIsMyTurn]     = useState(false);
  const timerRef                    = useRef(null);
  const prevPickRef                 = useRef(currentPick);

  const picksAway = myNextPick - currentPick;

  // ── Build context for AI ────────────────────────────────────
  const getDraftCtx = useCallback(() => buildDraftContext({
    platform,
    leagueName:   league?.name || 'My League',
    teamCount:    league?.total_rosters || league?.num_teams || 12,
    scoringType:  league?.scoring_settings?.rec === 1 ? 'PPR'
                : league?.scoring_settings?.rec === 0.5 ? 'Half-PPR' : 'Standard',
    sport:        'NFL',
    round,
    totalRounds:  league?.settings?.rounds || 15,
    currentPick,
    totalPicks:   (league?.total_rosters || 12) * (league?.settings?.rounds || 15),
    myNextPick,
    myRoster:     myRoster || [],
    allPicks:     allPicks || [],
    availablePlayers: availablePlayers || [],
  }), [platform, league, round, currentPick, myNextPick, myRoster, allPicks, availablePlayers]);

  // ── Fetch AI recommendation ─────────────────────────────────
  const fetchRecommendation = useCallback(async () => {
    if (!availablePlayers?.length) return;
    setAiLoading(true);
    setAiError('');
    try {
      const ctx  = getDraftCtx();
      const text = await getAIRecommendation(ctx);
      setAiRec(text);
    } catch (e) {
      if (e.message === 'ANTHROPIC_KEY_MISSING') {
        setAiError('Add your Anthropic API key to .env to enable AI picks.\nGet a free key at console.anthropic.com');
      } else {
        setAiError('AI temporarily unavailable. Check your connection.');
      }
    } finally {
      setAiLoading(false);
    }
  }, [getDraftCtx, availablePlayers]);

  // ── Ask custom question ─────────────────────────────────────
  async function handleAsk() {
    if (!question.trim()) return;
    setQLoading(true);
    setQAnswer('');
    try {
      const ctx = getDraftCtx();
      const ans = await askDraftQuestion(question.trim(), ctx);
      setQAnswer(ans);
    } catch {
      setQAnswer('AI unavailable right now. Check your API key.');
    } finally {
      setQLoading(false);
      setQuestion('');
    }
  }

  // ── Timer ───────────────────────────────────────────────────
  useEffect(() => {
    timerRef.current = setInterval(() => {
      setTimer(t => {
        if (t <= 1) return 60; // reset when pick made
        return t - 1;
      });
    }, 1000);
    return () => clearInterval(timerRef.current);
  }, []);

  // ── Detect new pick / my turn ───────────────────────────────
  useEffect(() => {
    if (currentPick !== prevPickRef.current) {
      prevPickRef.current = currentPick;
      setTimer(60); // reset clock

      if (currentPick + 1 === myNextPick) {
        // I'm next — vibrate and fetch fresh recommendation
        Vibration.vibrate([0, 300, 100, 300]);
        fetchRecommendation();
      }
    }
    setIsMyTurn(currentPick >= myNextPick);
  }, [currentPick, myNextPick, fetchRecommendation]);

  // ── Fetch on mount ──────────────────────────────────────────
  useEffect(() => {
    fetchRecommendation();
  }, []);

  const timerColor = timer <= 15 ? C.red : timer <= 30 ? C.orange : C.green;
  const timerPct   = `${(timer / 60) * 100}%`;

  return (
    <View style={s.screen}>
      {/* Header */}
      <View style={s.header}>
        <TouchableOpacity onPress={onBack}>
          <Text style={s.backTxt}>‹ Leagues</Text>
        </TouchableOpacity>
        <View style={s.livePill}>
          <View style={[s.liveDot, { backgroundColor: timerColor }]} />
          <Text style={[s.liveTxt, { color: timerColor }]}>
            {isMyTurn ? 'YOUR TURN' : platform.toUpperCase() + ' LIVE'}
          </Text>
        </View>
      </View>

      <FlatList
        data={allPicks || []}
        keyExtractor={item => String(item.pickNo)}
        style={s.screen}
        ListHeaderComponent={() => (
          <>
            {/* Draft status */}
            <View style={s.draftBar}>
              <View style={s.timerTrack}>
                <View style={[s.timerFill, { width: timerPct, backgroundColor: timerColor }]} />
              </View>
              <View style={s.draftRow}>
                <View style={s.draftCol}>
                  <Text style={s.dLabel}>Round</Text>
                  <Text style={s.dVal}>{round}</Text>
                </View>
                <View style={s.draftCol}>
                  <Text style={s.dLabel}>Pick</Text>
                  <Text style={s.dVal}>#{currentPick}</Text>
                </View>
                <View style={s.draftCol}>
                  <Text style={s.dLabel}>Mine</Text>
                  <Text style={s.dVal}>#{myNextPick}</Text>
                </View>
                <View style={[s.turnBadge, isMyTurn && s.turnBadgeActive]}>
                  <Text style={[s.turnBadgeTxt, isMyTurn && { color: C.bg }]}>
                    {isMyTurn ? 'YOUR TURN!' : `${Math.max(0, picksAway)} away`}
                  </Text>
                </View>
              </View>
            </View>

            {/* Timer strip */}
            <View style={[s.clockStrip, isMyTurn && { borderColor: timerColor + '66', backgroundColor: timerColor + '0d' }]}>
              <View style={[s.clockDot, { backgroundColor: timerColor }]} />
              <Text style={[s.clockTxt, { color: timerColor }]}>
                {isMyTurn ? "IT'S YOUR PICK — make it count!" : `${allPicks?.slice(-1)[0]?.manager || 'Manager'} is picking…`}
              </Text>
              <Text style={[s.clockNum, { color: timerColor }]}>
                0:{String(timer).padStart(2, '0')}
              </Text>
            </View>

            {/* AI Recommendation */}
            <View style={[s.aiCard, isMyTurn && { borderColor: C.green + '66' }]}>
              <View style={s.aiHeader}>
                <View style={[s.aiDot, aiLoading && s.aiDotThinking]} />
                <Text style={s.aiLabel}>
                  {aiLoading ? 'AI is thinking…' : `AI pick for #${myNextPick} — ${platform.toUpperCase()}`}
                </Text>
                <Text style={s.aiPlatform}>
                  {platform === 'espn' ? 'ESPN ADP' : platform === 'yahoo' ? 'Yahoo ADP' : 'Sleeper ADP'}
                </Text>
              </View>

              {aiLoading && (
                <View style={s.thinkingRow}>
                  {[0, 1, 2].map(i => (
                    <View key={i} style={[s.thinkDot, { animationDelay: `${i * 0.15}s` }]} />
                  ))}
                  <Text style={s.thinkingTxt}>Analyzing your roster and available players…</Text>
                </View>
              )}

              {!aiLoading && aiError && (
                <View style={s.errBox}>
                  <Text style={s.errTxt}>{aiError}</Text>
                </View>
              )}

              {!aiLoading && aiRec && (
                <Text style={s.aiRecTxt}>{aiRec}</Text>
              )}

              <TouchableOpacity style={s.refreshBtn} onPress={fetchRecommendation} disabled={aiLoading}>
                <Text style={s.refreshTxt}>{aiLoading ? 'Thinking…' : '↻ Refresh pick'}</Text>
              </TouchableOpacity>
            </View>

            {/* Ask AI anything */}
            <View style={s.askBox}>
              <TextInput
                style={s.askInput}
                placeholder={`Ask AI anything… "Adams or Pollard?"`}
                placeholderTextColor={C.muted}
                value={question}
                onChangeText={setQuestion}
                onSubmitEditing={handleAsk}
                returnKeyType="send"
              />
              <TouchableOpacity style={s.askBtn} onPress={handleAsk} disabled={qLoading || !question.trim()}>
                {qLoading
                  ? <ActivityIndicator color={C.bg} size="small" />
                  : <Text style={s.askBtnTxt}>Ask</Text>
                }
              </TouchableOpacity>
            </View>
            {!!qAnswer && (
              <View style={s.answerBox}>
                <Text style={s.answerTxt}>{qAnswer}</Text>
              </View>
            )}

            {/* My roster */}
            <Text style={s.sectionLabel}>My roster</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={s.rosterScroll}>
              {(myRoster || []).map((p, i) => (
                <View key={i} style={[s.rosterChip, { borderColor: (POS_COLORS[p.position] || C.muted) + '44' }]}>
                  <Text style={[s.rcPos, { color: POS_COLORS[p.position] || C.muted }]}>{p.position}</Text>
                  <Text style={s.rcName} numberOfLines={1}>{p.name?.split(' ').pop() || '–'}</Text>
                </View>
              ))}
              {(!myRoster || myRoster.length === 0) && (
                <Text style={[s.sectionLabel, { paddingTop: 10 }]}>No picks yet</Text>
              )}
            </ScrollView>

            <Text style={s.sectionLabel}>Live draft feed</Text>
          </>
        )}
        renderItem={({ item }) => (
          <View style={[s.pickRow, item.isMine && s.pickRowMine]}>
            <Text style={[s.pickNum, { color: item.isMine ? C.green : C.muted }]}>#{item.pickNo}</Text>
            <View style={[s.posBadge, { backgroundColor: (POS_COLORS[item.position] || C.muted) + '22' }]}>
              <Text style={[s.posTxt, { color: POS_COLORS[item.position] || C.muted }]}>{item.position}</Text>
            </View>
            <View style={{ flex: 1 }}>
              <Text style={[s.playerName, item.isMine && { color: C.white }]}>{item.playerName}</Text>
              <Text style={s.playerTeam}>Round {item.round} · {item.teamName || ''}</Text>
            </View>
            {item.isMine && <View style={s.myTag}><Text style={s.myTagTxt}>You</Text></View>}
          </View>
        )}
        ListFooterComponent={() => <View style={{ height: 32 }} />}
      />
    </View>
  );
}

const s = StyleSheet.create({
  screen:    { flex: 1, backgroundColor: C.bg },
  header:    { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 20, paddingBottom: 0 },
  backTxt:   { color: C.muted, fontSize: 14 },
  livePill:  { flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: 'rgba(74,222,128,0.1)', borderWidth: 1, borderColor: 'rgba(74,222,128,0.25)', borderRadius: 20, paddingVertical: 4, paddingHorizontal: 12 },
  liveDot:   { width: 6, height: 6, borderRadius: 3 },
  liveTxt:   { fontSize: 11, fontWeight: '700' },

  draftBar:   { margin: 16, marginBottom: 0, backgroundColor: C.surf, borderRadius: 16, padding: 16, borderWidth: 1, borderColor: C.border, overflow: 'hidden' },
  timerTrack: { position: 'absolute', top: 0, left: 0, right: 0, height: 3, backgroundColor: C.border },
  timerFill:  { position: 'absolute', top: 0, left: 0, height: 3 },
  draftRow:   { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 8 },
  draftCol:   { alignItems: 'center' },
  dLabel:     { fontSize: 10, color: C.muted, textTransform: 'uppercase', letterSpacing: 0.8 },
  dVal:       { fontSize: 17, fontWeight: '800', color: C.white, marginTop: 2 },
  turnBadge:  { backgroundColor: C.border, borderRadius: 20, paddingVertical: 5, paddingHorizontal: 12 },
  turnBadgeActive: { backgroundColor: C.green },
  turnBadgeTxt: { fontSize: 11, fontWeight: '700', color: C.muted },

  clockStrip: { marginHorizontal: 16, marginTop: 10, backgroundColor: 'rgba(74,222,128,0.05)', borderWidth: 1, borderColor: 'rgba(74,222,128,0.15)', borderRadius: 12, padding: 12, flexDirection: 'row', alignItems: 'center', gap: 8 },
  clockDot:   { width: 6, height: 6, borderRadius: 3, flexShrink: 0 },
  clockTxt:   { flex: 1, fontSize: 13, fontWeight: '500' },
  clockNum:   { fontSize: 20, fontWeight: '900' },

  aiCard:     { margin: 16, marginBottom: 0, backgroundColor: C.surf, borderRadius: 20, padding: 18, borderWidth: 1, borderColor: C.border },
  aiHeader:   { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 14 },
  aiDot:      { width: 8, height: 8, borderRadius: 4, backgroundColor: C.green, flexShrink: 0 },
  aiDotThinking: { opacity: 0.4 },
  aiLabel:    { fontSize: 11, color: C.green, textTransform: 'uppercase', letterSpacing: 1, fontWeight: '600', flex: 1 },
  aiPlatform: { fontSize: 10, color: C.muted },
  aiRecTxt:   { fontSize: 14, color: C.light, lineHeight: 22 },
  thinkingRow: { flexDirection: 'row', alignItems: 'center', gap: 8, paddingVertical: 8 },
  thinkDot:   { width: 8, height: 8, borderRadius: 4, backgroundColor: C.green, opacity: 0.6 },
  thinkingTxt: { fontSize: 13, color: C.muted, flex: 1 },
  errBox:     { backgroundColor: 'rgba(248,113,113,0.08)', borderWidth: 1, borderColor: 'rgba(248,113,113,0.2)', borderRadius: 10, padding: 12 },
  errTxt:     { color: C.red, fontSize: 13, lineHeight: 20 },
  refreshBtn: { marginTop: 14, alignSelf: 'flex-start' },
  refreshTxt: { fontSize: 12, color: C.muted },

  askBox:   { marginHorizontal: 16, marginTop: 10, flexDirection: 'row', gap: 8 },
  askInput: { flex: 1, backgroundColor: C.surf, borderWidth: 1, borderColor: C.border, borderRadius: 12, padding: 12, color: C.white, fontSize: 13 },
  askBtn:   { backgroundColor: C.green, borderRadius: 12, padding: 12, paddingHorizontal: 16, justifyContent: 'center' },
  askBtnTxt:{ color: C.bg, fontWeight: '700', fontSize: 13 },
  answerBox:{ marginHorizontal: 16, marginTop: 8, backgroundColor: 'rgba(34,211,238,0.06)', borderWidth: 1, borderColor: 'rgba(34,211,238,0.2)', borderRadius: 12, padding: 14 },
  answerTxt:{ fontSize: 13, color: C.light, lineHeight: 20 },

  sectionLabel: { paddingHorizontal: 16, paddingTop: 14, paddingBottom: 8, fontSize: 11, color: C.muted, textTransform: 'uppercase', letterSpacing: 1, fontWeight: '600' },
  rosterScroll: { paddingHorizontal: 16 },
  rosterChip:   { backgroundColor: C.surf, borderRadius: 12, padding: 10, marginRight: 8, borderWidth: 1, minWidth: 72, alignItems: 'center' },
  rcPos:        { fontSize: 9, fontWeight: '700', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 4 },
  rcName:       { fontSize: 12, fontWeight: '500', color: C.white, maxWidth: 70 },

  pickRow:     { marginHorizontal: 16, marginBottom: 6, backgroundColor: C.surf, borderRadius: 12, padding: 12, flexDirection: 'row', alignItems: 'center', gap: 10, borderWidth: 1, borderColor: 'transparent' },
  pickRowMine: { borderColor: 'rgba(74,222,128,0.25)', backgroundColor: 'rgba(74,222,128,0.04)' },
  pickNum:     { fontSize: 12, fontWeight: '700', width: 28, textAlign: 'center' },
  posBadge:    { width: 32, height: 32, borderRadius: 8, alignItems: 'center', justifyContent: 'center' },
  posTxt:      { fontSize: 10, fontWeight: '700' },
  playerName:  { fontSize: 13, fontWeight: '500', color: '#8b9cbf' },
  playerTeam:  { fontSize: 11, color: C.muted, marginTop: 1 },
  myTag:       { backgroundColor: 'rgba(74,222,128,0.12)', borderRadius: 6, paddingHorizontal: 8, paddingVertical: 3 },
  myTagTxt:    { fontSize: 10, color: C.green, fontWeight: '700' },
});
