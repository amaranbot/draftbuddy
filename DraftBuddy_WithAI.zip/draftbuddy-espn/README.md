# DraftBuddy — ESPN + Yahoo + Sleeper
## Run on your phone TODAY, no developer needed

---

## QUICK START (5 steps)

### 1. Install Node.js
https://nodejs.org → download LTS → install it

### 2. Install Expo Go on your phone
- iPhone → App Store → search "Expo Go"
- Android → Google Play → search "Expo Go"

### 3. Open Terminal/Command Prompt and run:
```
cd ~/Downloads/draftbuddy-espn
npm install
npx expo start
```

### 4. Scan the QR code with your phone camera (iPhone) or Expo Go (Android)

### 5. Connect your fantasy platforms in the app!

---

## HOW TO CONNECT ESPN (most popular)

### Public leagues (free, no setup):
1. Open ESPN Fantasy on desktop
2. Go to your league
3. Look at the URL: fantasy.espn.com/football/league?leagueId=**123456**
4. Copy that number
5. Paste it into DraftBuddy → Connect ESPN

### Private leagues (takes 2 extra minutes):
You need to copy two "cookies" from your browser.
Cookies are small pieces of data ESPN uses to keep you logged in.
DraftBuddy reads them directly — they never leave your phone.

**Chrome:**
1. Go to fantasy.espn.com on your computer (stay logged in)
2. Press F12 (or right-click → Inspect)
3. Click "Application" tab at the top
4. On the left: expand "Cookies" → click "https://fantasy.espn.com"
5. Find the row called **espn_s2** → click it → copy the entire Value
6. Find the row called **SWID** → copy the entire Value (it looks like {XXXXXXXX-XXXX-...})
7. Paste both into DraftBuddy

**That's it.** DraftBuddy stores them on your phone only.

---

## HOW TO CONNECT YAHOO

Yahoo requires you to approve access through their official login page.
DraftBuddy uses Yahoo's "Device Flow" — you see a short code, type it on Yahoo's website, done.

**One-time setup (only needed once ever):**
1. Go to developer.yahoo.com/apps/create
2. Sign in with your Yahoo account
3. Fill in:
   - App Name: DraftBuddy
   - App Type: Installed Application
   - API Permissions: check "Fantasy Sports" → Read
4. Click Create App
5. Copy your **Client ID**
6. Open the file: src/api/yahoo.js
7. Find line 1: `const YAHOO_CLIENT_ID = 'YOUR_YAHOO_CLIENT_ID'`
8. Replace `YOUR_YAHOO_CLIENT_ID` with your Client ID
9. Save the file and restart the app (`npx expo start`)

After that, connecting Yahoo in the app takes 30 seconds.

---

## HOW TO CONNECT SLEEPER

Easiest of all — just your username, no password, no setup.
1. Open Sleeper → tap your avatar → Profile
2. Copy your username
3. Paste it into DraftBuddy → Connect Sleeper

---

## TROUBLESHOOTING

**"Could not connect to ESPN"**
- Double-check your League ID (just the number, no other characters)
- If it's a private league, make sure you added the espn_s2 and SWID cookies

**ESPN cookies expired?**
- Cookies last about 1 year
- If they stop working: delete them in the app, go back to your browser and copy fresh ones

**Yahoo "Could not start Yahoo login"**
- Make sure you replaced YOUR_YAHOO_CLIENT_ID in yahoo.js with your real Client ID from developer.yahoo.com

**App won't scan QR code**
- Make sure your phone and computer are on the same WiFi
- Try typing the URL shown in terminal directly into Expo Go

**"No leagues found" on ESPN**
- The app looks for 2025 season leagues
- Make sure your league is set up for 2025 in ESPN

---

## WHAT DATA DRAFTBUDDY READS

| Platform | What we read | What we DON'T do |
|----------|-------------|-------------------|
| ESPN | League info, rosters, draft picks | Never post, never make picks |
| Yahoo | League info, rosters, draft picks | Never post, never make picks |
| Sleeper | League info, rosters, draft picks | Never post, never make picks |

All data is stored on YOUR phone only using AsyncStorage.
Nothing is sent to any DraftBuddy server.

---

## FILE STRUCTURE
```
draftbuddy-espn/
├── App.js                 ← All screens (splash, connect, home, draft)
├── package.json
├── src/
│   └── api/
│       ├── espn.js        ← ESPN Fantasy API calls
│       ├── yahoo.js       ← Yahoo Fantasy API + OAuth device flow
│       └── sleeper.js     ← Sleeper API calls
└── README.md
```
